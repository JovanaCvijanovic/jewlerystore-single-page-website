function prijava() {

    var name = document.getElementById('name').value;

    if (name == null || name == '') {
        alert('Unesite Vase ime');
        name.focus;
        return false;
    }

    var email = document.getElementById('email');
    var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

    if (!filter.test(email.value)) {
        alert('Unesite ispravnu email adresu');
        email.focus;
        document.getElementById('email').value = "";
        return false;
    }
    var number = document.getElementById('number');
    var filter =  /^\+?(\d{12}$)/;
    if (!filter.test(number.value)) {
    alert('Broj telefona mora biti formata +381... i mora sadrzati 12 cifara');
    number.focus;
    document.getElementById('number').value = "";
    return false;
    }

    var message = document.getElementById('message').value;

    if (message == null || message == '') {
        alert('Unesite Vasu poruku');
        message.focus;
        return false;

    }
    else {
        alert("Poruka je uspesno poslata");
        document.getElementById('name').value = "";
        document.getElementById('email').value = "";
        document.getElementById('number').value = "";
        document.getElementById('message').value = "";
        return true;
    }
}
